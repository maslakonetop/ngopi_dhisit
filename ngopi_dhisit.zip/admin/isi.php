<h2 class="mb-4 text-white">SAR ADMIN</h2>
<p class="text-white">Didalam page ini, Anda bisa melakukan pembuatan akun baru, mengedit akun baru, melakukan pembaruan akun.</p>
<p class="text-white">Serta Anda dapat melihat laporan harian, mingguan dan bulanan, dan melaporkannya dalam bentuk file Excel</p>