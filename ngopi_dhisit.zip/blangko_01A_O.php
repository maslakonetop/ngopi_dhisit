<?php
    include("layout/sidebar.php");
    include("layout/header.php");
    include("data/config.php");
?>
<style type="text/css">
      * {
        font-family: "Trebuchet MS";
      }
      h1 {
        text-transform: uppercase;
        color: salmon;
      }
    button {
          background-color: salmon;
          color: #fff;
          padding: 10px;
          text-decoration: none;
          font-size: 12px;
          border: 0px;
          margin-top: 20px;
    }
    label, textarea,input {
      margin-top: 10px;
      float: left;
      text-align: left;
      width: 100%;
    }
    textarea {
    padding: 10px;
    line-height: 1.5;
    border-radius: 5px;
    border: 2px solid #ccc;
    box-shadow: 1px 1px 1px #999;
    outline-color: salmon;
    }
    input {
      padding: 10px;
      width: 100%;
      box-sizing: border-box;
      background: #f8f8f8;
      border: 2px solid #ccc;
      outline-color: salmon;
    }
    div {
      width: 100%;
      height: auto;
    }
    .base {
      width: 100%;
      height: auto;
      padding: 20px;
      margin-left: auto;
      margin-right: auto;
      background: #ededed;
    }
</style>
<!DOCTYPE html>
<html>
<head>
    <title>Ngopi Dhisit Di Warung Jamu</title>
    <!-- Load file CSS Bootstrap offline -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">

</head>
<body>
<div class="container-fluid">
<h2 class="mb-4 text-center">Data Baru Usulan Luas Tanam Detail Blangko 01 A-O</h2>
    <hr style="border-top: 3px double #8c8b8b;">
    <div class="page-wrapper bg-gra-02 p-t-130 p-b-100 font-poppins">
        <div class="wrapper wrapper--w680">
            <div class="card card-4">
                <div class="card-body">
                <section class="base">
                    <h5>Display Data Irigasi</h5>
                    <form methode="get">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label" for="inlineFormCustomSelectPref">Pilih Daerah Irigasi</label>
                                    <div class="col-sm-3">
                                        <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="daerah_irigasi">
                                            <option disabled selected>Pilih Daerah Irigasi</option>
                                            <?php
                                                $stmt = "SELECT daerah_irigasi FROM `daerahirigasi`";
                                                $result = mysqli_query($koneksi,$stmt) or die(mysqli_error());
                                                while(list($category) = mysqli_fetch_row($result)){
                                                    $option = '<option value="'.$category.'">'.$category.'</option>';
                                                    echo ($option);
                                                    }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <button type="submit" style="margin-top: 1px;" class="btn btn-primary mb-2">Pilih</button>
                                </div>                                
                            </div>                                
                        </form>                    
                        <form method="POST" action="data/proses_simpan_blangko.php" enctype="multipart/form-data" id="usrform">
                            <?php

                                if (isset($_GET['daerah_irigasi'])) {
                                    $daerah=$_GET["daerah_irigasi"];

                                    $sql="SELECT * FROM `daerahirigasi` WHERE daerah_irigasi = '$daerah'";
                                    $hasil=mysqli_query($koneksi,$sql);
                                    $data = mysqli_fetch_assoc($hasil);
                                }else{
                                    $sql="SELECT * FROM `daerahirigasi`";
                                    $hasil=mysqli_query($koneksi,$sql);
                                    $data = mysqli_fetch_assoc($hasil);
                                }
                            ?>
                
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Daerah Irigasi</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="koderekening" value="<?php echo $data['daerah_irigasi']; ?>" placeholder="Daerah Irigasi" />
                                    </div>
                                </div>                            
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Kode Irigasi</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="kode_irigasi" value="<?php echo $data['kode_irigasi']; ?>"  />
                                    </div>
                                </div>                            
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Luas Sawah</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="luas_sawah" value="<?php echo $data['luas_sawah']; ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Balai PSDA</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="balai_psda" required=""value="<?php echo $data['balai_psda']; ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Periode Tahun Tanam</label> 
                                    <div class="col-sm-6">
                                        <input type="text" name="th_periode" required=""value="<?php echo $data['th_periode']; ?>" />
                                    </div>
                                </div>                            
                            </div>
                            <div class="col-6">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Perkumpulan Petani Pengguna Air</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="p3a" required=""value="<?php echo $data['p3a']; ?>" />
                                    </div>
                                </div>                                
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Kemantren</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jumlah_petak_tersier" required=""value="<?php echo $data['kemantren']; ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Unit Pelaksana Teknis</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="uptd" required=""value="<?php echo $data['uptd']; ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Masa Tanam I (MT-I)</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="masa_tanam1" required=""value="<?php echo $data['masa_tanam1']; ?>" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Masa Tanam II (MT-II)</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="masa_tanam2" required=""value="<?php echo $data['masa_tanam2']; ?>" />
                                    </div>   
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Masa Tanam III (MT-III)</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="masa_tanam3" required=""value="<?php echo $data['masa_tanam3']; ?>" />
                                    </div>  
                                </div> 
                            </div>                       
                        </div>                                            
                        <div class="col-12">
                            <hr style="	border-top: 3px double #8c8b8b;">                              
                        </div>
                        <h5>Display Data Tersier / Petak</h5>
                        <?php

                            if (isset($_GET['daerah_irigasi'])) {
                                $daerah=$_GET["daerah_irigasi"];

                                $sql="SELECT * FROM `saluranpetak` WHERE daerah_irigasi = '$daerah'";
                                $hasil=mysqli_query($koneksi,$sql);
                                $data1 = mysqli_fetch_assoc($hasil);
                            }
                        ?>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label" for="inlineFormCustomSelectPref">Pilih Daerah Irigasi</label>
                                    <div class="col-sm-3">
                                        <select class="custom-select my-1 mr-sm-2" id="inlineFormCustomSelectPref" name="petak">
                                            <option disabled selected>Pilih Pilih Petak/Tersier</option>
                                            <?php
                                                $stmt = "SELECT petak FROM `saluranpetak` where daerah_irigasi = '$daerah'";
                                                $result = mysqli_query($koneksi,$stmt) or die(mysqli_error());
                                                while(list($category) = mysqli_fetch_row($result)){
                                                    $option = '<option value="'.$category.'">'.$category.'</option>';
                                                    echo ($option);
                                                    }
                                            ?>
                                        </select>
                                    </div>
                                    <?php

                                    if (isset($_GET['petak'])) {
                                        $petak=$_GET["petak"];

                                        $sql="SELECT * FROM `saluranpetak` WHERE petak = '$petak'";
                                        $hasil=mysqli_query($koneksi,$sql);
                                        $data1 = mysqli_fetch_assoc($hasil);
                                    }
                                ?>
                                    <div class="col-sm-3">
                                        <button type="submit" style="margin-top: 1px;" class="btn btn-primary mb-2">Pilih</button>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Saluran Primer</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="saluran_primer" required=""value="<?php echo $data1['saluran_primer']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Saluran Sekunder</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="saluran_sekunder" required=""value="<?php echo $data1['saluran_sekunder']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Saluran Tersier</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="saluran_tersier" required=""value="<?php echo $data1['saluran_tersier']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Petak</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="petak" required=""value="<?php echo $data1['petak']; ?>" />
                                    </div>  
                                </div>                       
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Desa</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="desa" required=""value="<?php echo $data1['desa']; ?>" />
                                    </div>  
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Luas</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="luas" required=""value="<?php echo $data1['luas']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Jenis Tanaman 1</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam1" required=""value="<?php echo $data1['jenis_tanam1']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Jenis Tanaman 2</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam2" required=""value="<?php echo $data1['jenis_tanam2']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Jenis Tanam 3</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam3" required=""value="<?php echo $data1['jenis_tanam3']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-6 col-form-label">Jenis Tanam </label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam3" required=""value="<?php echo $data1['jenis_tanam4']; ?>" />
                                    </div>  
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                        <hr style="	border-top: 3px double #8c8b8b;">                              
                        </div>
                        <h5>Data Baru Usulan Per Masa Tanam <select class="custom-select my-1 mr-sm-2" style="width: 35%" id="inlineFormCustomSelectPref" name="petak">
                                            <option disabled selected>Pilih Masa Tanam</option>
                                            <option>Bulan OKT 2019 s/d bulan JAN 2020</option>
                                            <option>Bulan PEB. 2020 s/d  bulan  MEI  2020</option>
                                            <option>Bulan JUNI 2020  s/d  bulan  SEPT  2020</option>
                                        </select></h5>
                        <div class="row">
                            <div class="col-4">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Jenis Tanaman I</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam1" required=""value="<?php echo $data1['jenis_tanam1']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Jenis Tanaman II</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam1" required=""value="<?php echo $data1['jenis_tanam2']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Jenis Tanaman III</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam1" required=""value="<?php echo $data1['jenis_tanam3']; ?>" />
                                    </div>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Jenis Tanaman IV</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="jenis_tanam2" required=""value="<?php echo $data1['jenis_tanam4']; ?>" />
                                    </div>  
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Usulan Luas</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="luas" required=""value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div> 
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Usulan Luas</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="luas" required=""value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Usulan Luas</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="jenis_tanam1" required=""value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Usulan Luas</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="jenis_tanam2" required=""value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                            </div>
                            <div class="col-4">
                            <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Realisasi</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="luas" value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div> 
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Realisasi</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="luas" value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Realisasi</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="jenis_tanam1" value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                                <div class="form-group row">
                                    <label class="text-dark col-sm-4 col-form-label">Realisasi</label>
                                    <div class="col-sm-4">
                                        <input type="text" name="jenis_tanam2" value="" />
                                    </div>
                                    <label class="text-dark col-sm-4 col-form-label">Hektar</label>  
                                </div>
                                <div class="form-group row">
                                    <button class="btn btn-danger" type="submit">PROSES</button> 
                                </div>
                            </div>  
                        </div>                       
                    </form>
                    </div>
                </div>
            </div>
            
            </section>
        </div>
    </div>
<?php
    include("layout/footer.php");
?>