<?php
    include("layout/sidebar.php");
    include("layout/header.php");
    include("data/config.php");
?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script>
            function cek_db(){
                var id = $("#petak").val(); 
                $.ajax({
                url : 'data/auto_blangko1.php', // file proses penginputan
                data : "petak="+petak,
                }).success(function (data){
                var json = data,
                obj = JSON.parse(json);
                $('#daerah_irigasi').val(obj.daerah_irigasi); 
                $('#saluran_primer').val(obj.saluran_primer);
                $('#saluran_sekunder').val(obj.saluran_sekunder);
                $('#saluran_tersier').val(obj.saluran_tersier);
                $('#desa').val(obj.desa);    
                $('#luas').val(obj.luas);
                $('#jenis_tanam1').val(obj.jenis_tanam1);
                $('#jenis_tanam2').val(obj.jenis_tanam2);
                $('#jenis_tanam3').val(obj.jenis_tanam3);
                })
            }
        </script>
    <body>
    <div class="container-fluid">
        <form method="POST" action="master/simpan_master_irigasi.php">
        <section class="base">
            <h2 class="title text-center">Data Baru Usulan Luas Tanam Detail</h2>
            <h3 class="title text-center">Blangko 01 A-O</h3>
                <div class="row">
                    <div class="col-6"><!--left side -->
                        <div class="form-group row">
                            <label for="lname" class="col-sm-6 col-form-label">Petak</label>
                            <div class="col-sm-6">
                                <select name="uptd" class="custom-select" required="">
                                <option disabled selected>Pilih Petak</option>
                                <?php
                                $query = "SELECT petak FROM `saluranpetak` ORDER BY petak";
                                $result = mysqli_query($koneksi, $query);                                
                                    while(list($category) = mysqli_fetch_array($result)){
                                    $option = '<option class="text-uppercase" value="'.$category.'">'.$category.'</option>';
                                    echo ($option);
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="lname" class="col-sm-6 col-form-label">Kode Irigasi</label>
                            <div class="col-sm-6">
                                <input type="number" name="kode_iriasi" class="form-control" id="lname" required="" value="<?php echo $categorycategory['kodeirigas'];?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="lname" class="col-sm-6 col-form-label">Luas Sawah</label>
                        
                            <div class="col-sm-4">
                                <input type="text" class="form-control" name="luas_sawah" required="" value="" />
                            </div>
                            <div class="col-sm-2">
                                <label for="fname" class="col-sm-2 col-form-label">Hektar</label>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="lname" class="col-sm-6 col-form-label">Jumlah Petak Tersier</label>
                            <div class="col-sm-6">
                                <input type="text" class="form-control" name="jumlah_petak" required="" value="" />    
                            </div>
                        </div>
                        </div>                          
                    <div class="col-6">
                        <div class="form-group row">
                            <label for="email" class="col-sm-6 col-form-label">Masa Tanam</label>
                                <div class="col-sm-6">
                                <input type="text" class="form-control" name="masa_tanam" required=""value="" />
                                </div>                 
                        </div>
                    
                        <div class="form-group row">
                            <label for="email" class="col-sm-6 col-form-label">Balai PSDA</label>
                            <div class="col-sm-6">
                                <input type="text" name="balai_psda" class="form-control" id="fname" value="">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-sm-6 col-form-label">Satuan Kerja</label>
                            <div class="col-sm-6">
                                <input type="text" name="satuan_kerja" class="form-control" required="" id="lname" value="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-warning mb-4"><i class="fa fa-save"></i> Simpan</button>
                            </div>                            
                    </div><!--right side -->
                </div><!-- form for teacher/student-->
            </section>
        </form>
    </div>
<?php
    include("layout/footer.php");
?>